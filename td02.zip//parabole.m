function [ y ] = parabole( x )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

y = x.*x;
end

